package board.board_fullstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.sql.SQLException;

@SpringBootApplication
public class BoardFullstackApplication {

	public static void main(String[] args) {
        try {
            jdbc.db.dbs();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        SpringApplication.run(BoardFullstackApplication.class, args);
	}
}
