package board.board_fullstack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardFullstackApplicationTests {

	@Test
	void contextLoads() {
	}

}
