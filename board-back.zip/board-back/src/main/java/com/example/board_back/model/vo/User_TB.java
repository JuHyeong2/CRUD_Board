package com.example.board_back.model.vo;

import java.util.Date;

public class User_TB {

    private int no;
    private String name;
    private String id;
    private String phone;
    private String pwd;
    private String email;
    private String address;
    private Date date;

    public User_TB() {
    }

    public User_TB(int no, String name, String id, String phone, String pwd, String email, String address, Date date) {
        this.no = no;
        this.name = name;
        this.id = id;
        this.phone = phone;
        this.pwd = pwd;
        this.email = email;
        this.address = address;
        this.date = date;
    }

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
