package com.example.board_back.service;

import com.example.board_back.DataNotFoundException;
import com.example.board_back.model.vo.User_TB;
import com.example.board_back.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserService {
    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User_TB getUser(String id, String pwd) {
        Optional<User_TB> user = this.userRepository.findByIdAndPw(id, pwd);
        if (user.isPresent()) {
            return user.get();
        }else {
            throw new DataNotFoundException("user not found");
        }
    }
}
