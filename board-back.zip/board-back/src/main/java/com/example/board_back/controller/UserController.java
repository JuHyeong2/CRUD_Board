package com.example.board_back.controller;


import com.example.board_back.model.vo.User_TB;
import com.example.board_back.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@RequestMapping("/user")
@Controller
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String login(Model model, @RequestParam(value="id") String id, @RequestParam(value="pwd") String pwd) {
        User_TB user = this.userService.getUser(id, pwd);

        return "user_login";
    }

    @GetMapping("/join")
    public String join(Model model) {

        return "user_join";
    }

    @GetMapping("/findIdPw")
    public String findId(Model model) {

        return "user_find";
    }

    @GetMapping("/delete")
    public String delete(Model model) {

        return "user_delete";
    }
}
