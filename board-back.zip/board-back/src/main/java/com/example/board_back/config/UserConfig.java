package com.example.board_back.config;

import com.example.board_back.repository.JdbcTeamplateUserRepository;
import com.example.board_back.repository.UserRepository;
import com.example.board_back.service.UserService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
public class UserConfig {

    private final DataSource dataSource;

    public UserConfig(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Bean
    public UserService userService() {
        return new UserService(userRepository());
    }

    @Bean
    public UserRepository userRepository() {
        return new JdbcTeamplateUserRepository(dataSource);
    }
}
