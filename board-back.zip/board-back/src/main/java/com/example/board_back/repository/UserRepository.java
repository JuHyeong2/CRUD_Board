package com.example.board_back.repository;

import com.example.board_back.model.vo.User_TB;

import java.util.List;
import java.util.Optional;

public interface UserRepository {
    User_TB save(User_TB member);
    Optional<User_TB> findByIdAndPw(String id, String pwd);
}
