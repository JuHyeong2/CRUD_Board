package com.example.board_back.repository;

import com.example.board_back.model.vo.User_TB;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import javax.sql.DataSource;
import java.util.List;
import java.util.Optional;

public class JdbcTeamplateUserRepository implements UserRepository {
    private final JdbcTemplate jdbcTemplate;

    public JdbcTeamplateUserRepository(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public User_TB save(User_TB member) {
        return null;
    }

    @Override
    public Optional<User_TB> findByIdAndPw(String id, String pwd) {
        List<User_TB> rs = jdbcTemplate.query("select * form user_tb where user_id = ? and user_pwd = ?", userRowMapper(), id, pwd);
        return rs.stream().findAny();
    }

    private RowMapper<User_TB> userRowMapper() {
        return (rs, rowNum) -> {
            User_TB user = new User_TB();
            user.setName(rs.getString("name"));
            return user;
        };
    }
}
