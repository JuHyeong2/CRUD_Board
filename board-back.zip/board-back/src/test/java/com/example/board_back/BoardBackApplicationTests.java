package com.example.board_back;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.example.board_back.model.vo.User_TB;
import com.example.board_back.repository.UserRepository;
import com.example.board_back.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@SpringBootTest
class BoardBackApplicationTests {

	@Autowired UserRepository userRepository;
	@Autowired UserService userService;

	@Test
	public void 로그인(){
		User_TB user = new User_TB();
		String id = "qhem1";
		String pwd = "qwer1";
		userService.getUser(id, pwd);

	}
}
