package com.example.board_back.user.repository;

import com.example.board_back.user.model.vo.User;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {
    private final SqlSessionTemplate sql;

    @Autowired
    public UserRepository(SqlSessionTemplate sql) {
        this.sql = sql;
    }

    public int join(User user){
        return sql.insert("User.join", user);
    }

    public User login(User user) {
        return sql.selectOne("User.login", user);
    }

    public int update(User user) {
        return sql.update("User.update", user);
    }
}
