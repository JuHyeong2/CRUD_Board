package com.example.board_back.user.controller;

import com.example.board_back.user.model.vo.User;
import com.example.board_back.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/user")
@Controller
public class UserController {

    private final UserService userService;
    public static User u = null;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String login(){
        return "user/login";
    }

    @PostMapping("/login")
    public String login(@RequestParam("user_id") String user_id, @RequestParam("user_pwd") String user_pwd) {
        User user = new User();
        user.setUser_id(user_id);
        user.setUser_pwd(user_pwd);
        User rs = userService.login(user);
        if (rs != null) {
            u = rs;
            System.out.println("로그인 성공");
            return "redirect:/user/update";
        }else{
            System.out.println("아이디와 비밀번호를 확인하세요");
            return "user/login";
        }
    }

    @GetMapping("/join")
    public String join(){
        return "user/join";
    }

    @PostMapping("/join")
    public String join(User user) {
        int rs = userService.join(user);
        if (rs > 0){
            System.out.println("회원가입에 성공하였습니다.");
            return "redirect:/user/login";
        }else {
            System.out.println("회원가입에 실패하였습니다.");
            return "user/join";
        }
    }

    @GetMapping("/update")
    public String update(Model model){
        model.addAttribute("user", u);
        return "user/update";
    }

    @PostMapping("/update")
    public String update(User user){
        int rs = userService.update(user);
        if (rs > 0){
            System.out.println("수정 완료");
            System.out.println(u.getUser_name());
            u = user;
            System.out.println(u.getUser_name());
            return "redirect:/user/";
        }else {
            System.out.println("수정 실패");
            return "user/login";
        }
    }
}
