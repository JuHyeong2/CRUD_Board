package com.example.board_back.controller;


import com.example.board_back.model.vo.User;
import com.example.board_back.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/user")
@Controller
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/login")
    public String login(){
        return "user/login";
    }

    @PostMapping("/login")
    public String login(@RequestParam("user_id") String user_id, @RequestParam("user_pwd") String user_pwd) {
        User user = new User(); // user 객체로 만들어서(id, pwd) insert 보내기
        user.setUser_id(user_id);
        user.setUser_pwd(user_pwd);
        User rs = userService.login(user);
        if (rs != null) {
            System.out.println("로그인 성공");
            return "redirect:/main";
        }else{
            System.out.println("아이디와 비밀번호를 확인하세요");
            return "user/login";
        }
    }

    @GetMapping("/join")
    public String join(){
        return "user/join";
    }

    @PostMapping("/join")
    public String join(User user) {
        int rs = userService.join(user);
        if (rs > 0){
            return "redirect:/login";
        }else {
            System.out.println("회원가입에 실패하였습니다.");
            return "user/join";
        }
    }

    @GetMapping("/update")
    public String update(){
        return "user/update";
    }

    @GetMapping("/delete")
    public String delete(){
        return "user/delete";
    }
}
