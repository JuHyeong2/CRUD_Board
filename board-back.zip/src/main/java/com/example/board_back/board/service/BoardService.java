package com.example.board_back.board.service;

import java.util.List;

import com.example.board_back.board.model.vo.Board;
import com.example.board_back.board.repository.BoardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoardService {

    @Autowired
    private BoardRepository boardRepository;

    public List<Board> getAllBoards() {
        return boardRepository.getAllBoards(); // 모든 게시글 조회
    }

    public Board getBoardByNo(int boardNo) {
        return boardRepository.getBoardByNo(boardNo); // 특정 게시글 조회
    }

    public void createBoard(Board board) {
        boardRepository.createBoard(board); // 게시글 생성
    }

    public void updateBoard(Board board) {
        boardRepository.updateBoard(board); // 게시글 수정
    }

    public void deleteBoard(int boardNo) {
        boardRepository.deleteBoard(boardNo); // 게시글 삭제
    }
}
