package com.example.board_back.board.repository;

import com.example.board_back.board.model.vo.Board;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class BoardRepository {
    private final SqlSession sql;

    @Autowired
    public BoardRepository(SqlSession sql) {
        this.sql = sql;
    }

    //게시글 목록 조회
    public List<Board> getAllBoards() {
        return sql.selectList("Board.list"); // 결과를 담을 리스트
    }

    //게시글 내용 뿌려주는 메소드
    public Board getBoardByNo(int boardNo) {
        return sql.selectOne("Board.detail", boardNo);
    }

    //게시글 생성 사용자로부터 값들 받아와서 insert해주는 부분임
    public int createBoard(Board board) {
        return sql.insert("Board.insert", board);
    }

    //게시글 수정. 사용자로부터 값들 받아와서 update해주는 내용
    public int updateBoard(Board board) {
        return sql.update("Board.update", board);
    }

    public int deleteBoard(int boardNo) {
        return sql.delete("Board.delete", boardNo);
    }
}
