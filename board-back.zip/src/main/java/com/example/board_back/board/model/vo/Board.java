package com.example.board_back.board.model.vo;

import java.sql.Timestamp;

public class Board {
    private int board_no, board_view, user_no;
    private String board_title, board_detail;
    private Timestamp board_time;

    public Board() {
    }

    public Board(int board_no, int board_view, String board_title, String board_detail, int user_no, Timestamp board_time) {
        this.board_no = board_no;
        this.board_view = board_view;
        this.board_title = board_title;
        this.board_detail = board_detail;
        this.user_no = user_no;
        this.board_time = board_time;
    }

    public int getBoard_no() {
        return board_no;
    }

    public void setBoard_no(int board_no) {
        this.board_no = board_no;
    }

    public int getBoard_view() {
        return board_view;
    }

    public void setBoard_view(int board_view) {
        this.board_view = board_view;
    }

    public int getUser_no() {
        return user_no;
    }

    public void setUser_no(int user_no) {
        this.user_no = user_no;
    }

    public String getBoard_title() {
        return board_title;
    }

    public void setBoard_title(String board_title) {
        this.board_title = board_title;
    }

    public String getBoard_detail() {
        return board_detail;
    }

    public void setBoard_detail(String board_detail) {
        this.board_detail = board_detail;
    }

    public Timestamp getBoard_time() {
        return board_time;
    }

    public void setBoard_time(Timestamp board_time) {
        this.board_time = board_time;
    }
}
