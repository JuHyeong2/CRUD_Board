package com.example.board_back.board.controller;

import com.example.board_back.board.model.vo.Board;
import com.example.board_back.board.service.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/board")
public class BoardController {

    @Autowired // 의존성 주입하는 어노테이션임
    private BoardService boardService;

    @GetMapping("/list")
    public String getAllBoards(Model model) {
        model.addAttribute("board", boardService.getAllBoards());
        return "board/list";
    }

    @GetMapping("/detail")
    public String getBoardByNo(Model model) {
        Board board = boardService.getBoardByNo(1);
        model.addAttribute("board", board);
        return "board/detail";
    }

    @PostMapping // http메소드중 하나로 
    public String createBoard(@RequestBody Board board) {
        boardService.createBoard(board);
        return "redirect:/board";
    }

    @PutMapping("/{no}")
    public void updateBoard(@RequestBody Board board) {
        boardService.updateBoard(board);
    }

    @DeleteMapping("/{no}")
    public void deleteBoard(@PathVariable int no) {
        boardService.deleteBoard(no);
    }
}
