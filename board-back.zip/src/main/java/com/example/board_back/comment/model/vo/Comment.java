package com.example.board_back.comment.model.vo;

import java.sql.Timestamp;

public class Comment {
    private int comment_no;
    private int user_no;
    private int board_no;
    private String comment_detail;
    private Timestamp comment_time;

    public Comment() {
    }

    public Comment(int comment_no, int user_no, int board_no, String comment_detail, Timestamp comment_time) {
        this.comment_no = comment_no;
        this.user_no = user_no;
        this.board_no = board_no;
        this.comment_detail = comment_detail;
        this.comment_time = comment_time;
    }

    public int getComment_no() {
        return comment_no;
    }

    public void setComment_no(int comment_no) {
        this.comment_no = comment_no;
    }

    public int getUser_no() {
        return user_no;
    }

    public void setUser_no(int user_no) {
        this.user_no = user_no;
    }

    public int getBoard_no() {
        return board_no;
    }

    public void setBoard_no(int board_no) {
        this.board_no = board_no;
    }

    public String getComment_detail() {
        return comment_detail;
    }

    public void setComment_detail(String comment_detail) {
        this.comment_detail = comment_detail;
    }

    public Timestamp getComment_time() {
        return comment_time;
    }

    public void setComment_time(Timestamp comment_time) {
        this.comment_time = comment_time;
    }
}
