package com.example.board_back.comment.controller;

import com.example.board_back.comment.service.CommentService;
import com.example.board_back.comment.model.vo.Comment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@RequestMapping("/comment")
@Controller
public class CommentController {

    @Autowired
    private CommentService service;

    public CommentController(CommentService service) {
        this.service = service;
    }

    //댓글 쓰기 메소드
    public void insertComment(Comment comment){
        int result = service.insertComment(comment);
    }

    //댓글 조회 메소드
    @GetMapping("/detail")
    public String getCommentByBoardNo(Model model){

        //조회 번호 입력
        int boardNo = 1;
        List<Comment> list = service.getCommentByBoardNo(boardNo);
        Comment comment = list.get(0);

        model.addAttribute("comment", comment);
        return "comment/detail";
    }

    //댓글 수정 메소드
    public void updateComment(){

        //수정할 내용 입력
        Comment comment = new Comment();
        comment.setComment_no(1);
        comment.setComment_detail("");

        //수정할 댓글 번호
        int no = 0;

        int result = service.updateComment(comment);
    }

    //댓글 삭제 메소드
    public void deleteComment(){

        //삭제할 댓글 번호
        int commentNo = 0;

        int result = service.deleteComment(commentNo);
    }
}
