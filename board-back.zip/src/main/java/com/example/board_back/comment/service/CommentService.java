package com.example.board_back.comment.service;

import com.example.board_back.comment.model.vo.Comment;
import com.example.board_back.comment.repository.CommentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentService {

    @Autowired
    private CommentRepository commentRepository;

    public int insertComment(Comment comment) { //등록
        return commentRepository.insertComment(comment);
    }

    public List<Comment> getCommentByBoardNo(int boardNo) { //조회
        return commentRepository.getCommentByBoardNo(boardNo);
    }

    public int updateComment(Comment comment) { //수정
        return commentRepository.updateComment(comment);
    }

    public int deleteComment(int commentNo) { //삭제
        return commentRepository.deleteComment(commentNo);
    }
}
