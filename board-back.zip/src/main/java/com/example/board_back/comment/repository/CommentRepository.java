package com.example.board_back.comment.repository;

import com.example.board_back.comment.model.vo.Comment;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class CommentRepository {
    private final SqlSession sql;

    @Autowired
    public CommentRepository(SqlSession sql) {
        this.sql = sql;
    }

    public List<Comment> getCommentByBoardNo(int boardNo) {
        return sql.selectList("Comment.detail", boardNo);
    }

    public int insertComment(Comment comment) {
        return sql.insert("Comment.insert", comment);
    }

    public int updateComment(Comment comment) {
        return sql.update("Comment.update", comment);
    }

    public int deleteComment(int commentNo) {
        return sql.delete("Comment.delete", commentNo);
    }
}
