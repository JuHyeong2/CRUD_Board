package com.example.board_back.service;

import com.example.board_back.model.vo.User;
import com.example.board_back.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public int join(User user) {
        return userRepository.join(user);
    }

    public User login(User user) {
        return userRepository.login(user);
    }

    public int update(User user) {
        return userRepository.update(user);
    }

    public User selectOne(int userNo) {
        return userRepository.selectOne(userNo);
    }
}
