package com.example.board_back;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardBackApplicationTests {

}
